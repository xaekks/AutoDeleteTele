# Commands

```
start -  start bot 📩📩
set_time - set auto delete time (only second)
```

Automatically Delete Massage In Group....[ Just Edit - API_ID+HASH+MOGODB+BOT_TOKEN+USERNAME ]
